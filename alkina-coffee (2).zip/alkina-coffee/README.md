# Alkina Coffee, Company Profile
Tugas UTS | Siti Safira Andini | NIM 24612020274

Stack: PHP 8+ (native, tanpa framework) + MySQL (PDO) + HTML/CSS/JS.

## Fitur backend
- **Routing**: front controller `public/index.php` (tabel rute `METODE /path`), halaman 404 dan 500.
- **Integrasi template**: `render()` memasukkan view ke `app/views/layout.php`.
- **Validasi & pemrosesan form kontak**: `handleContact()` di `app/bootstrap.php` (CSRF token, honeypot, validasi nama/email/telepon/subjek/pesan, prepared statement PDO, pola Post-Redirect-Get).
- **Database MySQL**: `database/alkina_coffee.sql` (tabel `services`, `team_members`, `portfolio`, `contact_messages`).

## Cara menjalankan
1. Aktifkan MySQL (XAMPP/Laragon), lalu impor `database/alkina_coffee.sql` (phpMyAdmin > Import).
2. Cek kredensial di `app/config.php`.
3. Jalankan salah satu:
   - Terminal: `php -S localhost:8000 -t public public/index.php` lalu buka http://localhost:8000
   - XAMPP: salin folder ke `htdocs`, buka http://localhost/alkina-coffee/public/ (mod_rewrite aktif)
4. Lihat pesan masuk: `SELECT * FROM contact_messages ORDER BY created_at DESC;`

## Struktur
```
public/        index.php (router), .htaccess, assets/css, assets/js
app/           bootstrap.php, config.php, views/ (layout + halaman)
database/      alkina_coffee.sql
```
Catatan: data Portfolio dan deskripsi layanan adalah contoh, sesuaikan di file SQL.
