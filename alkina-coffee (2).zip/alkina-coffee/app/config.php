<?php
// Sesuaikan dengan pengaturan MySQL (XAMPP default: user root, password kosong)
return [
  'db' => ['host'=>'127.0.0.1','name'=>'alkina_coffee','user'=>'root','pass'=>'','charset'=>'utf8mb4'],
  'site' => [
    'name'=>'Alkina Coffee','address'=>'Jl. Alfa 1 No. 70, Cimone',
    'hours'=>'08.00 – 22.00 setiap hari',
    'student'=>'Siti Safira Andini','nim'=>'24612020274',
  ],
];
