<section class="page"><div class="wrap">
  <h1>Portfolio</h1>
  <p class="lead">Jejak kerja dan kegiatan Alkina Coffee.</p>
  <div class="cols2">
    <?php foreach ($items as $p): ?>
      <article class="box work">
        <div class="meta"><span class="tag"><?= e($p['category']) ?></span><span><?= e($p['year']) ?></span></div>
        <h2><?= e($p['title']) ?></h2>
        <p><?= e($p['description']) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</div></section>
