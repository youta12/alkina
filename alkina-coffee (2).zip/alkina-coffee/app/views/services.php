<section class="page"><div class="wrap">
  <h1>Our Services</h1>
  <p class="lead">Yang bisa kamu dapatkan di Alkina Coffee.</p>
  <div class="cols3">
    <?php foreach ($items as $i): ?>
      <article class="box"><span class="ico" aria-hidden="true"><?= e($i['icon']) ?></span><h2><?= e($i['title']) ?></h2><p><?= e($i['description']) ?></p></article>
    <?php endforeach; ?>
  </div>
</div></section>
