<?php $s = cfg()['site'];
$nav = ['/'=>'Home','/about'=>'About Us','/vision-mission'=>'Vision & Mission','/services'=>'Services','/team'=>'Team','/portfolio'=>'Portfolio','/contact'=>'Contact Us']; ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | Alkina Coffee</title>
<meta name="description" content="Alkina Coffee, coffeeshop bertema industrial yang pet friendly di Cimone. Buka setiap hari 08.00–22.00.">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700&family=Work+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="<?= url('assets/img/favicon.png') ?>">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body>
<a class="skip" href="#main">Lewati ke konten</a>
<header class="top">
  <div class="wrap bar">
    <a class="brand" href="<?= url() ?>" aria-label="Alkina Coffee, ke beranda"><img src="<?= url('assets/img/mark-light.png') ?>" alt="" width="40" height="46">Alkina<span>Coffee</span></a>
    <button class="burger" aria-expanded="false" aria-controls="menu" aria-label="Buka menu"><i></i><i></i><i></i></button>
    <nav id="menu" aria-label="Navigasi utama">
      <?php foreach ($nav as $href => $label): ?>
        <a href="<?= url($href) ?>"<?= $path === $href ? ' class="on" aria-current="page"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </div>
</header>
<main id="main"><?= $content ?></main>
<footer class="foot">
  <div class="wrap fgrid">
    <div>
      <p class="brand"><img src="<?= url('assets/img/mark-light.png') ?>" alt="" width="40" height="46">Alkina<span>Coffee</span></p>
      <p>Coffeeshop industrial yang ramah hewan peliharaan.</p>
    </div>
    <div>
      <h3>Kunjungi kami</h3>
      <p><?= e($s['address']) ?></p>
      <p>Buka <?= e($s['hours']) ?></p>
    </div>
    <div>
      <h3>Halaman</h3>
      <ul>
        <?php foreach ($nav as $href => $label): ?><li><a href="<?= url($href) ?>"><?= e($label) ?></a></li><?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="wrap copy">© <?= date('Y') ?> Alkina Coffee. Tugas UTS oleh <?= e($s['student']) ?> (NIM <?= e($s['nim']) ?>).</div>
</footer>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
