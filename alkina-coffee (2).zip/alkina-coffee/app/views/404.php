<section class="page"><div class="wrap"><h1>Halaman tidak ditemukan</h1><p class="lead">Alamat yang kamu buka tidak ada.</p><a class="btn" href="<?= url() ?>">Kembali ke beranda</a></div></section>
