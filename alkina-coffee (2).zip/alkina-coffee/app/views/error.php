<section class="page"><div class="wrap"><h1>Terjadi kesalahan</h1>
<p class="lead">Server belum bisa memuat halaman ini. Pastikan MySQL aktif, database <b>alkina_coffee</b> sudah diimpor, dan <code>app/config.php</code> sesuai.</p>
<p class="meta-err"><?= e($msg) ?></p></div></section>
