<section class="page"><div class="wrap">
  <h1>About Us</h1>
  <div class="two">
    <div class="prose">
      <p>Alkina Coffee adalah coffeeshop bertema industrial yang berlokasi di Jl. Alfa 1 No. 70, Cimone. Kami menghadirkan ruang yang kokoh dan apa adanya, dengan material mentah seperti beton dan besi sebagai karakter utama.</p>
      <p>Kami juga pet friendly. Pengunjung boleh membawa hewan peliharaan, sehingga kopi, teman, dan anabul bisa dinikmati dalam satu tempat.</p>
      <p>Kami buka setiap hari pukul 08.00 sampai 22.00, dari kopi pagi sebelum bekerja hingga obrolan malam.</p>
    </div>
    <div>
    <img class="logo-full" src="<?= url('assets/img/logo-full-dark.png') ?>" alt="Logo Alkina Coffee" width="260">
    <dl class="facts">
      <div><dt>Konsep</dt><dd>Industrial</dd></div>
      <div><dt>Lokasi</dt><dd>Cimone</dd></div>
      <div><dt>Jam buka</dt><dd>08.00–22.00, setiap hari</dd></div>
      <div><dt>Kebijakan</dt><dd>Pet friendly</dd></div>
    </dl>
    </div>
  </div>
</div></section>
