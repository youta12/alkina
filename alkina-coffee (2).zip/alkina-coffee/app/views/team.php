<section class="page"><div class="wrap">
  <h1>Our Team</h1>
  <p class="lead">Orang-orang di balik bar Alkina Coffee.</p>
  <div class="cols4">
    <?php foreach ($items as $m):
      $ini = implode('', array_map(fn($w) => mb_strtoupper(mb_substr($w, 0, 1)), array_slice(explode(' ', $m['name']), 0, 2))); ?>
      <article class="box person">
        <div class="avatar" aria-hidden="true"><?= e($ini) ?></div>
        <h2><?= e($m['name']) ?></h2>
        <p class="role"><?= e($m['role']) ?></p>
        <p><?= e($m['bio']) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</div></section>
