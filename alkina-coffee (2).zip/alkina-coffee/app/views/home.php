<section class="hero">
  <div class="wrap hgrid">
    <div>
      <h1>Kopi yang kuat, tempat yang jujur.</h1>
      <p class="lead">Alkina Coffee adalah coffeeshop bertema industrial di Cimone. Duduk di antara beton, besi, dan aroma kopi, dan ajak anabulmu ikut serta.</p>
      <div class="btns"><a class="btn" href="<?= url('contact') ?>">Hubungi kami</a><a class="btn ghost" href="<?= url('services') ?>">Lihat layanan</a></div>
    </div>
    <aside class="plate" aria-label="Jam buka">
      <span class="rv tl"></span><span class="rv tr"></span><span class="rv bl"></span><span class="rv br"></span>
      <p class="plate-k">Buka setiap hari</p>
      <p class="plate-t">08.00–22.00</p>
      <p class="plate-a">Jl. Alfa 1 No. 70, Cimone</p>
      <p class="plate-p">🐾 Pet friendly</p>
    </aside>
  </div>
</section>
<section class="sec">
  <div class="wrap cols3">
    <article class="box"><h2>Interior industrial</h2><p>Dinding beton, rangka besi, dan lampu logam menciptakan ruang yang tegas namun hangat.</p></article>
    <article class="box"><h2>Boleh bawa hewan</h2><p>Anjing dan kucing diterima di Alkina Coffee. Tamu bisa bersantai tanpa meninggalkan peliharaannya.</p></article>
    <article class="box"><h2>Dibuat oleh barista</h2><p>Setiap gelas diseduh langsung oleh tim kami, dari espresso hingga seduhan manual.</p></article>
  </div>
</section>
<section class="sec alt">
  <div class="wrap cta"><h2>Mau reservasi atau bertanya?</h2><a class="btn" href="<?= url('contact') ?>">Kirim pesan</a></div>
</section>
