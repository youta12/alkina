<section class="page"><div class="wrap">
  <h1>Vision &amp; Mission</h1>
  <div class="two">
    <article class="box big"><h2>Visi</h2><p>Menjadi coffeeshop industrial pilihan di Cimone yang dikenal karena kopi berkualitas dan suasana ramah bagi semua tamu, termasuk hewan peliharaan.</p></article>
    <article class="box big"><h2>Misi</h2>
      <ul class="tick">
        <li>Menyajikan kopi dan minuman dengan rasa konsisten dari bahan pilihan.</li>
        <li>Menyediakan ruang industrial yang nyaman untuk bertemu, belajar, dan bekerja.</li>
        <li>Menerima hewan peliharaan dengan aman dan tertib.</li>
        <li>Melayani dengan ramah dan cepat setiap hari, pukul 08.00–22.00.</li>
        <li>Membangun komunitas pecinta kopi dan hewan di sekitar Cimone.</li>
      </ul>
    </article>
  </div>
</div></section>
