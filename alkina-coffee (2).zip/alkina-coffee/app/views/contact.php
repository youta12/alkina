<?php $err = $flash['errors'] ?? []; $old = $flash['old'] ?? [];
$f = fn($k) => e($old[$k] ?? '');
$fe = fn($k) => isset($err[$k]) ? '<span class="err" id="e-'.$k.'" role="alert">'.e($err[$k]).'</span>' : ''; ?>
<section class="page"><div class="wrap">
  <h1>Contact Us</h1>
  <div class="two">
    <div>
      <div class="box"><h2>Alkina Coffee</h2>
        <p>Jl. Alfa 1 No. 70, Cimone</p>
        <p>Buka 08.00–22.00, setiap hari</p>
        <p>Pet friendly 🐾</p></div>
      <iframe class="map" title="Peta lokasi Alkina Coffee" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
        src="https://www.google.com/maps?q=Jl.+Alfa+1+No.+70+Cimone&amp;output=embed"></iframe>
    </div>
    <form id="form" class="box form" method="post" action="<?= url('contact') ?>" novalidate>
      <h2>Kirim pesan</h2>
      <?php if (!empty($flash['success'])): ?><p class="ok" role="status"><?= e($flash['success']) ?></p><?php endif; ?>
      <?php if (isset($err['form'])): ?><p class="err box-err" role="alert"><?= e($err['form']) ?></p><?php endif; ?>
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
      <label>Nama<input name="name" value="<?= $f('name') ?>" maxlength="100" required autocomplete="name" aria-describedby="e-name"><?= $fe('name') ?></label>
      <label>Email<input type="email" name="email" value="<?= $f('email') ?>" maxlength="150" required autocomplete="email" aria-describedby="e-email"><?= $fe('email') ?></label>
      <label>Nomor telepon (opsional)<input type="tel" name="phone" value="<?= $f('phone') ?>" maxlength="16" autocomplete="tel" aria-describedby="e-phone"><?= $fe('phone') ?></label>
      <label>Subjek<input name="subject" value="<?= $f('subject') ?>" maxlength="150" required aria-describedby="e-subject"><?= $fe('subject') ?></label>
      <label>Pesan<textarea name="message" rows="5" maxlength="1000" required aria-describedby="e-message"><?= $f('message') ?></textarea><?= $fe('message') ?></label>
      <button class="btn" type="submit">Kirim pesan</button>
    </form>
  </div>
</div></section>
