<?php
declare(strict_types=1);
$config = require __DIR__ . '/config.php';

function cfg(): array { global $config; return $config; }

function db(): PDO {
  static $pdo = null;
  if ($pdo === null) {
    $c = cfg()['db'];
    $pdo = new PDO("mysql:host={$c['host']};dbname={$c['name']};charset={$c['charset']}", $c['user'], $c['pass'], [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false,
    ]);
  }
  return $pdo;
}

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function base(): string {
  return rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
}
function url(string $p = ''): string { return base() . '/' . ltrim($p, '/'); }

function csrf(): string {
  return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
}

// Integrasi template: view dirender lalu dimasukkan ke layout
function render(string $view, string $title, array $data = []): void {
  extract($data);
  $path = $GLOBALS['path'];
  ob_start();
  require __DIR__ . "/views/$view.php";
  $content = ob_get_clean();
  require __DIR__ . '/views/layout.php';
}

// Validasi & pemrosesan formulir kontak
function handleContact(): void {
  $in = [];
  foreach (['name','email','phone','subject','message'] as $k) {
    $in[$k] = trim((string)($_POST[$k] ?? ''));
  }
  $err = [];

  if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
    $err['form'] = 'Sesi formulir tidak valid. Muat ulang halaman lalu kirim lagi.';
  }
  if (($_POST['website'] ?? '') !== '') { // honeypot anti-bot
    $err['form'] = 'Pengiriman ditolak.';
  }
  $len = fn(string $s) => mb_strlen($s, 'UTF-8');

  if ($in['name'] === '') $err['name'] = 'Nama wajib diisi.';
  elseif ($len($in['name']) < 3 || $len($in['name']) > 100) $err['name'] = 'Nama harus 3–100 karakter.';
  elseif (!preg_match("/^[\p{L}\s.'-]+$/u", $in['name'])) $err['name'] = 'Nama hanya boleh berisi huruf.';

  if ($in['email'] === '') $err['email'] = 'Email wajib diisi.';
  elseif (!filter_var($in['email'], FILTER_VALIDATE_EMAIL) || $len($in['email']) > 150) $err['email'] = 'Format email belum benar, contoh: nama@email.com.';

  if ($in['phone'] !== '' && !preg_match('/^(\+62|62|0)[0-9]{8,13}$/', $in['phone'])) $err['phone'] = 'Nomor telepon tidak valid, contoh: 081234567890.';

  if ($in['subject'] === '') $err['subject'] = 'Subjek wajib diisi.';
  elseif ($len($in['subject']) < 3 || $len($in['subject']) > 150) $err['subject'] = 'Subjek harus 3–150 karakter.';

  if ($in['message'] === '') $err['message'] = 'Pesan wajib diisi.';
  elseif ($len($in['message']) < 10) $err['message'] = 'Pesan minimal 10 karakter.';
  elseif ($len($in['message']) > 1000) $err['message'] = 'Pesan maksimal 1000 karakter.';

  if ($err) {
    $_SESSION['flash'] = ['errors' => $err, 'old' => $in];
  } else {
    try {
      $st = db()->prepare('INSERT INTO contact_messages (name,email,phone,subject,message,ip_address) VALUES (?,?,?,?,?,?)');
      $st->execute([$in['name'], $in['email'], $in['phone'] ?: null, $in['subject'], $in['message'], $_SERVER['REMOTE_ADDR'] ?? null]);
      $_SESSION['flash'] = ['success' => 'Terima kasih, ' . $in['name'] . '. Pesanmu sudah kami terima dan akan dibalas lewat email.'];
      unset($_SESSION['csrf']);
    } catch (Throwable $ex) {
      $_SESSION['flash'] = ['errors' => ['form' => 'Pesan belum tersimpan karena gangguan server. Coba lagi sebentar lagi.'], 'old' => $in];
    }
  }
  header('Location: ' . url('contact') . '#form');
  exit;
}
