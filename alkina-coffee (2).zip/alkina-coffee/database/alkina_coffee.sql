-- Database Alkina Coffee | UTS - Siti Safira Andini (24612020274)
CREATE DATABASE IF NOT EXISTS alkina_coffee CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE alkina_coffee;

DROP TABLE IF EXISTS contact_messages, services, team_members, portfolio;

CREATE TABLE services (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  icon VARCHAR(10) NOT NULL,
  title VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  sort_order TINYINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE team_members (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  role VARCHAR(60) NOT NULL,
  bio TEXT NOT NULL,
  sort_order TINYINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE portfolio (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  category VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  year YEAR NOT NULL
) ENGINE=InnoDB;

CREATE TABLE contact_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(20) NULL,
  subject VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_created (created_at)
) ENGINE=InnoDB;

INSERT INTO services (icon, title, description, sort_order) VALUES
('☕','Kopi & Minuman','Espresso, manual brew, dan minuman non-kopi yang diracik barista berpengalaman dari biji pilihan.',1),
('🐾','Area Pet Friendly','Bawa anabul kesayanganmu. Kami menyediakan area nyaman agar tamu dan hewan peliharaan sama-sama betah.',2),
('🍰','Makanan Pendamping','Camilan dan makanan ringan yang cocok dipadukan dengan setiap seduhan kopi.',3),
('💻','Ruang Nongkrong & Kerja','Interior industrial dengan meja luas, cocok untuk bertemu teman, belajar, atau bekerja.',4),
('🎉','Reservasi & Acara Kecil','Tempat untuk arisan, ulang tahun, dan pertemuan komunitas dengan jumlah terbatas.',5),
('🫘','Penjualan Biji Kopi','Biji kopi kemasan untuk diseduh di rumah, bisa digiling sesuai alat seduhmu.',6);

INSERT INTO team_members (name, role, bio, sort_order) VALUES
('Kevin Kuwantto','Owner','Pendiri Alkina Coffee yang membangun konsep coffeeshop industrial dan ramah hewan peliharaan di Cimone.',1),
('Safira','Senior Barista','Meracik menu signature dan memastikan standar rasa tetap konsisten di setiap gelas.',2),
('Jelita','Senior Barista','Ahli seduh manual dan latte art, serta membimbing barista baru di bar.',3),
('Hasna','Junior Barista','Barista muda yang cekatan melayani tamu dan terus belajar teknik seduh.',4);

-- Data contoh, silakan sesuaikan dengan kegiatan Alkina Coffee yang sebenarnya
INSERT INTO portfolio (title, category, description, year) VALUES
('Desain Interior Industrial','Ruang','Dinding beton ekspos, rangka besi hitam, dan lampu gantung logam sebagai identitas visual Alkina Coffee.',2025),
('Peluncuran Menu Signature','Produk','Menu andalan hasil racikan tim barista yang menjadi favorit pengunjung.',2025),
('Pet Day Weekend','Acara','Akhir pekan khusus untuk pengunjung yang membawa hewan peliharaan.',2026),
('Workshop Dasar Latte Art','Komunitas','Sesi belajar singkat bersama barista senior untuk pecinta kopi pemula.',2026);
