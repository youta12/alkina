<?php
declare(strict_types=1);
// Mendukung `php -S localhost:8000 -t public public/index.php`
if (PHP_SAPI === 'cli-server') {
  $f = __DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
  if (is_file($f)) return false;
}
session_start();
require __DIR__ . '/../app/bootstrap.php';

// ---- Routing ----
$uri  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
$path = '/' . trim(substr($uri, strlen(base())), '/');
$path = $path === '/index.php' ? '/' : $path;
$method = $_SERVER['REQUEST_METHOD'];

$routes = [
  'GET /'               => fn() => render('home', 'Beranda'),
  'GET /about'          => fn() => render('about', 'About Us'),
  'GET /vision-mission' => fn() => render('vision', 'Vision & Mission'),
  'GET /services'       => fn() => render('services', 'Our Services', ['items' => db()->query('SELECT * FROM services ORDER BY sort_order')->fetchAll()]),
  'GET /team'           => fn() => render('team', 'Our Team', ['items' => db()->query('SELECT * FROM team_members ORDER BY sort_order')->fetchAll()]),
  'GET /portfolio'      => fn() => render('portfolio', 'Portfolio', ['items' => db()->query('SELECT * FROM portfolio ORDER BY year DESC, id DESC')->fetchAll()]),
  'GET /contact'        => function () {
    $flash = $_SESSION['flash'] ?? []; unset($_SESSION['flash']);
    render('contact', 'Contact Us', ['flash' => $flash]);
  },
  'POST /contact'       => 'handleContact',
];

try {
  $handler = $routes["$method $path"] ?? null;
  if ($handler) { $handler(); }
  else { http_response_code(404); render('404', 'Halaman tidak ditemukan'); }
} catch (Throwable $ex) {
  http_response_code(500);
  render('error', 'Terjadi kesalahan', ['msg' => $ex->getMessage()]);
}
