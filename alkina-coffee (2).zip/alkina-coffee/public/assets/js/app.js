(() => {
  const b = document.querySelector('.burger'), m = document.getElementById('menu');
  b.addEventListener('click', () => {
    const open = m.classList.toggle('open');
    b.setAttribute('aria-expanded', open);
  });
  // Validasi sisi klien (validasi utama tetap di server)
  const form = document.querySelector('.form');
  if (form) form.addEventListener('submit', e => {
    let bad = false;
    form.querySelectorAll('.cerr').forEach(n => n.remove());
    form.querySelectorAll('[required]').forEach(el => {
      if (!el.value.trim() || (el.type === 'email' && !/^\S+@\S+\.\S+$/.test(el.value))) {
        bad = true;
        const s = document.createElement('span');
        s.className = 'err cerr'; s.textContent = 'Kolom ini wajib diisi dengan benar.';
        el.after(s);
      }
    });
    if (bad) e.preventDefault();
  });
})();
